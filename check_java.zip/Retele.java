class Retele {
    public static void main(String[] args) {
    }
}